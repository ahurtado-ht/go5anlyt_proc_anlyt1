========================================
APLICACION: procesador de analytics
========================================
permite leer los eventos reportados en kafka, hacerles algun tratameinto (que en este moemnto es nulo)
y posteriormente enviarlos a un repositorio de datos.



========================================
instalacion/configuracion wso2das
========================================

descargar jdk 1.7
descargar wso2-das
descargar kafka (0.8.1.1 para el caso de wso2) y copiar librerias a wso2das acorde a (https://docs.wso2.com/display/DAS300/Kafka+Event+Receiver): 
	de: C:\.work\kafka_2.11-0.8.2.2\libs
	a:  C:\.work\wso2das-3.0.0\repository\components\lib
configurar kafka como event receiver
	toca subir kafka
	toca tener acceso a kafka y zookeper (192.168.1.40:9092 y :2181) desde la maquina de analytics
	seguir la guia referenciada 
		- para crear eventstream
			MISPESOS_EVT_DATA
		- para crear un receiver tipo kafka
			zookeperIp:192.168.1.40
			zookeperPort:9092
			kafkaTopic: my-topic-test
			groupId: 0
			threads: 1
			
		- para crear un producer tipo rdbms (en este caso oracle)
		    crear usuario oracle
				connect sys as sysdba/anlyt
				
				create user anlyt identified by anlyt;
				grant connect, resource to anlyt;			
				
				connect anlyt/anlyt
				
				CREATE TABLE "ANLYT"."EVENT_DATA" 
				(	"EVENTOID" VARCHAR2(200 BYTE), 
					"EVENTOTIPO" VARCHAR2(20 BYTE)
				);
				
				
			descargar los drivers 
				- oracle: http://www.oracle.com/technetwork/database/features/jdbc/index-091264.html
			copiar los drivers de oracle a 
				wso2das-3.0.0\repository\components\lib
			crear un datasource
				name:EVT_RECEIVER_DS
				type:default
				driver: oracle.jdbc.OracleDriver
				url: jdbc:oracle:thin:@192.168.1.236:1521:PERSONAL 
				user: anlyt
				pwd: anlyt
				
			crear producer: 
				publisher-name: PUBLISHER_RDBMS
				table-name: EVENT_DATA
				
				<?xml version="1.0" encoding="UTF-8"?>
				<eventPublisher name="PUBLISHER_RDBMS" statistics="disable"
				  trace="disable" xmlns="http://wso2.org/carbon/eventpublisher">
				  <from streamName="MISPESOS_EVT_DATA" version="1.0.0"/>
				  <mapping customMapping="disable" type="map"/>
				  <to eventAdapterType="rdbms">
					<property name="datasource.name">EVT_RECEIVER_DS</property>
					<property name="table.name">EVENT_DATA</property>
					<property name="execution.mode">insert</property>
				  </to>
				</eventPublisher>				











				
				
				
puerto: 1521
usuario: sys
nombre: PERSONAL
clave: meconio3

			
		
		NOTA: mapear en etc/hosts (para que wso2 se pueda conectar a la cola kafka):
			192.168.1.40	gofive.mispesos
	
	usar los archivos del proyecto para crear la definicion del flow.
	
	
	
		
		
WSO2-das
		campos: 

========================================
envio a repositorio
========================================






		
========================================
REFERENCIAS
========================================

- tutorial de wso2-das
	https://docs.wso2.com/display/DAS300/Quick+Start+Guide