
base de datos donde se hace ingestion de los eventos y se pasan
se maneja inicialmetne relacional

# etl se realiza con flume+morphlines
# db: se usa hive/hadoop


-------------------------
PREPARACION
-------------------------

sudo mkdir /.apps
sudo mkdir /.tools
sudo mkdir /.work
sudo chown vagrant:vagrant /.work
sudo chown vagrant:vagrant /.apps
sudo chown vagrant:vagrant /.tools



-------------------------
INGESTION CON FLUME 
-------------------------

flume se debe instalar en el nodo hadoop (conectar como vagrant/vagrant)
y debe tener conectividad con kafka


# flume  - prerrequisitos

(0) descargar kafka
cd /.tools
wget http://www.apache.org/dist/kafka/0.9.0.0/kafka_2.11-0.9.0.0.tgz
cp kafka_2.11-0.9.0.0.tgz  /.work
cd /.work
tar -xvf kafka_2.11-0.9.0.0.tgz

(1) descargar:
cd /.tools
wget http://www.apache.org/dist/flume/1.6.0/apache-flume-1.6.0-bin.tar.gz
cp apache-flume-1.6.0-bin.tar.gz /.work/
cd /.work
tar -xvf apache-flume-1.6.0-bin.tar.gz

(2) verificar jdk existente
java -version

(3) adicionar libreria zookeper a flume
export FLUME_HOME=/.work/apache-flume-1.6.0-bin

#cd $FLUME_HOME/conf ; cp flume-env.sh.template flume-env.sh
en el archivo conf/flume-env.sh adicionar 
FLUME_CLASSPATH="/.work/kafka_2.11-0.9.0.0/libs/zookeeper-3.4.6.jar"

(4) configurar etc hosts de la maquina de analitica
# sudo vi /etc/hosts
# adicionar mapping broker
192.168.1.40	gofive.mispesos



# DESCARGAR PROYECTO
cd /.apps
git clone https://github.com/ahurtado-ht/go5anlyt_proc_horton.git
export APP_HOME=/.apps/go5anlyt_proc_horton


# PRUEBA0
# probar funcionamiento de flume acorde al ejemplo https://flume.apache.org/FlumeUserGuide.html
# este abre un socket en el puerto 44444
# cd $APP_HOME
# cp example.conf $FLUME_HOME/conf

cd $FLUME_HOME
bin/flume-ng agent --conf conf --conf-file conf/example.conf --name a1 -Dflume.root.logger=INFO,console

# probar con: telnet localhost 44444

# PRUEBA1
# probar conexion flume-kafka
# cd $APP_HOME
# cp flume_conf0.conf $FLUME_HOME/conf

cd $FLUME_HOME
bin/flume-ng agent --conf conf --conf-file conf/flume_conf0.conf --name tier1 -Dflume.root.logger=INFO,console


# PRUEBA2
# subir archivos desde kafka a hdfs

# 1. en la maquina horton, crear el directorio donde se almacenan los datos
hadoop fs -mkdir /tmp/kafka/

# 2. copiar el archivo xxxx.conf a $FLUME_HOME/conf
# cd $APP_HOME
# cp flume_conf1.conf $FLUME_HOME/conf

cd $FLUME_HOME
bin/flume-ng agent --conf conf --conf-file conf/flume_conf1.conf --name tier1 -Dflume.root.logger=INFO,console

# ejecutar el job flume desde kafka hacia hdfs
cd $FLUME_HOME
bin/flume-ng agent --conf conf --conf-file conf/flume_conf1.conf --name tier1 -Dflume.root.logger=INFO,console

# probar enviando 2 mensajes desde la app que emula los eventos
# luego ir a hadoop-ambari, http://192.168.1.41:8080 y abrir el visor hdfs para ver el contenido de los archivos.
# cada uno de los archivos es el json recibido desde la app







----------------------------------------------------
REPOSITORIO DE ANALISIS CON HIVE - CREAR ESTRUCTURAS
----------------------------------------------------
para poder leer los datos en hive que se tienen en hdfs
se necesita un HiveSerde, que es una especie de adaptador que indica cómo procesar y entender el json a hive.
Algunos encontrados para hive son: 
- https://github.com/rcongiu/Hive-JSON-Serde (al parecer el mas usado)
tiene una version binaria en: http://www.congiu.net/hive-json-serde/1.3.6/hdp23/, que es la que se usará dado que ya viene compilada
pero si se necesita compilar: 
	cd /.apps
	git clone https://github.com/rcongiu/Hive-JSON-Serde.git json-serde
	cd json-serde
	mvn -Phdp23 clean package
	# nota: al parecer se necesita una dependencia de jdo que no se encuentra en ningun repositorio.
	# para instalar: 
	# wget http://www.datanucleus.org/downloads/maven2/javax/jdo/jdo2-api/2.3-ec/jdo2-api-2.3-ec.jar
	# mvn install:install-file -DgroupId=javax.jdo -DartifactId=jdo2-api -Dversion=2.3-ec -Dpackaging=jar -Dfile=jdo2-api-2.3-ec.jar
	#
	# el artefacto se crea en : json-serde/target/json-serde-VERSION-jar-with-dependencies.jar	
	# cp json-serde/target/*with-dependencies.jar /.work/json-serde
	
cd /.tools
wget http://www.congiu.net/hive-json-serde/1.3.6/hdp23/json-serde-1.3.6-jar-with-dependencies.jar
mkdir /.work/json-serde
cp json-serde-1.3.6-jar-with-dependencies.jar /.work/json-serde
	
con root ejecutar:	
# Your "root" user seems to lack a home directory which it is trying to
# use for itself. Do this:
# sudo -u hdfs hadoop fs -mkdir /user/root
# sudo -u hdfs hadoop fs -chown root:root /user/root

## add root to hdfs group
# usermod -a -G hdfs root

# opcion para no tener que cargar jar en cada sesion:
# agregar a /usr/hdp/current/hive-client/auxlib (en cada nodo hadoop) 
# You can update your hive-site.xml to have the hive.aux.jars.path property set to the complete path to your jar hiveserde-1.0.jar
# agregar esta libreria con el usuario root
# mkdir -p /usr/hdp/current/hive-client/auxlib
# cp /.work/json-serde/json-serde-1.3.7-SNAPSHOT-jar-with-dependencies.jar  /usr/hdp/current/hive-client/auxlib





hive
delete jar /.work/json-serde/json-serde-1.3.6-jar-with-dependencies.jar;
add jar /.work/json-serde/json-serde-1.3.7-SNAPSHOT-jar-with-dependencies.jar;

DROP TABLE EVENT_DATA;
CREATE EXTERNAL TABLE EVENT_DATA (
  eventoId            string,
  eventoTipo          string,
  eventoFecha         string,
  eventoDireccionIp   string,
  eventoCanal         string,
  eventoRespNroConfirmacion  string,
  eventoRespCod       string,
  eventoRespDescripcion      string,
  comercioCod         string,
  cajaId              string,
  txOrigenCuenta      string,
  txDestinoCuenta     string,
  cajeroId            string,
  bonoSerial          string,
  bonoEspecieCod      string,
  bonoEmisorCod       string,
  bonoEspecieVer      string,
  bonoEstado          string,
  bonoValor           double,
  bonoDenominacion    string,
  bonoFechaVencimiento       string
) ROW FORMAT SERDE 'org.openx.data.jsonserde.JsonSerDe'
LOCATION '/tmp/kafka/my-topic-test';

exit;


----------------------------------------------------
GRAFICOS DE ANALISIS -ZEPPELIN
----------------------------------------------------
ir a http://192.168.1.41:9995/#/
crear notebook
ver que los plugins esten arriba

%hive
select eventoId, eventoTipo, comercioCod 
  from event_data






#STORED AS TEXTFILE



REFERNCIAS
- ejemplo ingestion  
  http://www.lopakalogic.com/articles/hadoop-articles/log-files-flume-hive/ 
  https://xyu.io/2015/07/13/building-a-faster-etl-pipeline-with-flume-kafka-and-hive/
  http://www.formhadoop.es/etl-flume-morphlines/
- usando kibana
  http://mmolimar.blogspot.com.co/2015/01/analyzing-tweets-from-flume-in-kibana.html
- json serde
  (azure) https://azure.microsoft.com/en-us/documentation/articles/hdinsight-using-json-in-hive/
  (horton) http://hortonworks.com/blog/howto-use-hive-to-sqlize-your-own-tweets-part-two-loading-hive-sql-queries/
- uso json serde en hive
  http://thornydev.blogspot.com.co/2013/07/querying-json-records-via-hive.html