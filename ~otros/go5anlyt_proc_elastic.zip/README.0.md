descargar elastic

correr logstash

bin/logstash -f logstash-conf1.conf



